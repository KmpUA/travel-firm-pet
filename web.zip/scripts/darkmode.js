const checkbox = document.querySelector('.navigation-container');
checkbox.addEventListener("click", () => {
  document.body.classList.toggle("dark")
})